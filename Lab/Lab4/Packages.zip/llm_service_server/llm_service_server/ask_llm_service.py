import os

import rclpy
from rclpy.node import Node

from strings_interfaces.srv import StringService

from google import genai
from google.genai import types


MODEL_ID = "gemini-robotics-er-1.5-preview"


class LLMService(Node):
    def __init__(self):
        super().__init__("llm_service_server")

        api_key = os.environ.get("GEMINI_API_KEY", "").strip()
        if not api_key:
            self.get_logger().warn(
                "GEMINI_API_KEY is not set. Export it first:\n"
                "export GEMINI_API_KEY='YOUR_KEY'"
            )

        self.client = genai.Client(api_key=api_key) if api_key else genai.Client()

        self.srv = self.create_service(StringService, "ask_llm", self.handle_request)
        self.get_logger().info("✅ Ready: /ask_llm (strings_interfaces/srv/StringService)")

    def handle_request(self, request, response):
        prompt = request.request_data.strip()

        if not prompt:
            response.response_data = "Error: empty request_data."
            return response

        try:
            llm_resp = self.client.models.generate_content(
                model=MODEL_ID,
                contents=[prompt],
                config=types.GenerateContentConfig(temperature=0.5),
            )
            text = (llm_resp.text or "").strip()
            response.response_data = text if text else "Error: empty LLM response."
        except Exception as e:
            response.response_data = f"Error: {e}"

        return response


def main():
    rclpy.init()
    node = LLMService()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()
